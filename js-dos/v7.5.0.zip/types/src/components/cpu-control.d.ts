import { Props } from "../player-app";
export declare function SideBarCpuControl(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
