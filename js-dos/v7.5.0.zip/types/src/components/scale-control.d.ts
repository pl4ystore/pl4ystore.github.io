import { Props } from "../player-app";
export declare function ActionBarScaleControl(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
export declare function SideBarScaleControl(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
