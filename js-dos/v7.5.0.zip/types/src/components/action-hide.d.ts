import { Props } from "../player-app";
export declare function ActionHide(props: Props & {
    class: string;
}): import("preact").VNode<any> | import("preact").VNode<any>[];
