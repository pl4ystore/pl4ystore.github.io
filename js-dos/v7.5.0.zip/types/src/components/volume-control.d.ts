import { Props } from "../player-app";
export declare function ActionBarVolumeControl(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
export declare function SideBarVolumeControl(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
