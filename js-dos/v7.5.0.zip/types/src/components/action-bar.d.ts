import { Props } from "../player-app";
export declare function ActionBar(props: Props): import("preact").VNode<any> | import("preact").VNode<any>[];
