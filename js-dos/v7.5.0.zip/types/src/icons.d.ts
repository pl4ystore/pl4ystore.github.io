export declare const Icons: {
    XCircle: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    UserCircle: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Mobile: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    SwithcHorizontal: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    EyeOff: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Pause: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Play: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    VolumeUp: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    VolumeOff: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    PencilAlt: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    ArrowsExpand: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    ArrowsCircleLeft: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    ArrowsCircleRight: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    ChevronLeft: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    ChevronRight: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    DotsHorizontal: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Download: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Upload: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Plus: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    CursorClick: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Cursor: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Refresh: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    CurrencyDollar: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    QuestionMarkCircle: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Discord: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Telegram: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Twitter: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    FloppyDisk: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Online: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    Offline: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
    InformationCircle: (props: {
        class: string;
    }) => import("preact").VNode<any> | import("preact").VNode<any>[];
};
