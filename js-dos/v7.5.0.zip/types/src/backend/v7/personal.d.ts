export declare function getPersonalBundleUrl(namespace: string, id: string, bundleUrl: string): string;
export declare function putPersonalBundle(namespace: string, id: string, bundleUrl: string, data: Uint8Array): Promise<void>;
